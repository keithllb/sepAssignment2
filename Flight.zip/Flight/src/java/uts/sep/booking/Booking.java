/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.booking;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Booking {
    
    @XmlElement(name = "bookingID")    
    private int bookingID;
        
    @XmlElement(name = "flightID")    
    private int flightID;
    
    @XmlElement(name = "userID")    
    private int userID;
    
    @XmlElement(name = "userName")    
    private String userName;
    
    @XmlElement(name = "userEmail")    
    private String userEmail;
    
    @XmlElement(name = "userDOB")    
    private String userDOB;
    
    public Booking()
    {
        
    }
    
    public Booking(int bookingID,int userID ,int flightID, String userName, String userEmail, String userDOB)
    {
        this.bookingID = bookingID;
        this.flightID = flightID;
        this.userID = userID;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userDOB = userDOB;
    }
    
    public int getBookingID(){
        return bookingID;
    }
    
    public void setBookingID(int bookingID){
        this.bookingID = bookingID;
    }
    
    public int getUserID(){
        return userID;
    }
    
    public void setUserID(int userID){
        this.userID = userID;
    }    
    
    public int getFlightID(){
        return flightID;
    }
    
    public void setFlightID(int flightID){
        this.flightID = flightID;
    }
    
    public String getUserName(){
        return userName;
    }
    
    public void setUserName(String userName){
        this.userName = userName;
    }    
        
    public String getUserEmail(){
        return userEmail;
    }
    
    public void setUserEmail(String userEmail){
        this.userEmail = userEmail;
    }    

    public String getUserDOB(){
        return userDOB;
    }
    
    public void setUserDOB(String userDOB){
        this.userDOB = userDOB;
    }        
}
