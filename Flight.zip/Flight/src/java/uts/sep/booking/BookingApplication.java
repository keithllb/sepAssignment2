/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.booking;

import java.io.*;
import java.util.Iterator;
import javax.xml.bind.*;

public class BookingApplication implements Serializable{
    
    private String filePath;
    private Bookings bookings;
    
    public BookingApplication(){}
    
    public BookingApplication(String filePath, Bookings bookings)
    {
        super();
        this.filePath = filePath;
        this.bookings = bookings;
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    public void cancelBooking(int userID)
    {
        Iterator<Booking> iterator = bookings.getList().iterator();
        while(iterator.hasNext())
        {
            Booking booking = iterator.next();
            if(booking.getUserID() == userID)
            {
                iterator.remove();
            }
        }
    }

    public void setFilePath(String filePath) throws Exception {
        
        JAXBContext jc = JAXBContext.newInstance(Bookings.class);
        Unmarshaller u = jc.createUnmarshaller();

        this.filePath = filePath;
        
        FileInputStream fin = new FileInputStream(filePath);
        bookings = (Bookings) u.unmarshal(fin); 		
        fin.close();

    }
    
    public void updateXML(Bookings bookings, String filePath) throws Exception {
        this.bookings = bookings;
        this.filePath = filePath;
        
        JAXBContext jc = JAXBContext.newInstance(Bookings.class);
        Marshaller m = jc.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        FileOutputStream fout = new FileOutputStream(filePath);
        m.marshal(bookings, fout);
        fout.close();
    }

    public Bookings getBookings() {
        return bookings;
    }


    public void setBookings(Bookings bookings) {
        this.bookings = bookings;
    }
    
}
