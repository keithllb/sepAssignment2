package uts.sep.booking;

import java.io.Serializable;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import uts.sep.booking.Bookings;



public class TestJAXB implements Serializable {
	public static void main(String[] args) throws Exception {
	
		Bookings bookings = new Bookings();
                bookings.addBooking(new Booking(123, 432, 2343, "Tom", "tomy@gm.com", "1992-02-12"));
                bookings.addBooking(new Booking(122, 431, 2343, "Dom", "domy@gm.com", "1991-02-12"));
                bookings.removeBooking(new Booking(123, 432, 2343, "Tom", "tomy@gm.com", "1992-02-12"));
		// Boilerplate code to convert objects to XML...
		JAXBContext jc = JAXBContext.newInstance(Bookings.class);
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(bookings, System.out);
	}
}
