/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.booking;

import java.util.*;
import java.io.Serializable;
import javax.xml.bind.annotation.*;
import uts.sep.user.User;

@XmlAccessorType(XmlAccessType.FIELD) 

@XmlRootElement(name = "bookings")
public class Bookings implements Serializable {
    
    @XmlElement(name = "booking")
    private ArrayList<Booking> bookingList = new ArrayList<Booking>();
 
    // return flight list
    public ArrayList<Booking> getList() {
        return bookingList;
    }
     
    // add booking
    public void addBooking(Booking booking) {
        bookingList.add(booking);
    }
    
    // remove booking
    public void removeBooking(Booking booking) {
        bookingList.remove(booking);
    }
    
    
    // array list that return all booking
    public ArrayList<Booking> getAllBooking()
    {
        ArrayList<Booking> list = new ArrayList<Booking>();
        
        for(Booking booking : bookingList)
        {
            list.add(booking);
        }
        return list;
    }
    
    // return booking list that matches flight ID
    public ArrayList<Booking> searchFlight(int flightID)
    {
        ArrayList<Booking> list = new ArrayList<Booking>();
        
        for(Booking booking : bookingList)
        {
            if(booking.getFlightID() == flightID)
            {
                 list.add(booking);
            }
        }  
        return list;
    }
    
    // return booking list that matches user ID
    public Booking getBooking(int userID)
    {        
        for(Booking booking : bookingList)
        {
            if(booking.getUserID() == userID)
             return booking;
        }  
        return null;
    }
    
     // check list that matches user ID
    public boolean checkUserID(int userID)
    {        
        for(Booking booking : bookingList)
        {
            if(booking.getUserID() == userID)
             return true;
        }  
        return false;
    }
    
    

}