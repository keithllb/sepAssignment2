/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.flight;

import java.io.*;
import java.util.ArrayList;
import javax.xml.bind.*;

/**
 *
 * @author 11661143
 */
public class FlightApplication implements Serializable{
    
    private String filePath;
    private Flights flights;
    
    public FlightApplication(){}
    
    public FlightApplication(String filePath, Flights flights)
    {
        super();
        this.filePath = filePath;
        this.flights = flights;
    }
    
    /*
     * @return the filePath
     */
    public String getFilePath() {
        return filePath;
    }
   
    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath) throws JAXBException, IOException, Exception {
        
        JAXBContext jc = JAXBContext.newInstance(Flights.class);
        Unmarshaller u = jc.createUnmarshaller();

        this.filePath = filePath;   

        FileInputStream fin = new FileInputStream(filePath);
        flights = (Flights) u.unmarshal(fin); 		
        fin.close();
    }
    
    public void updateXML(Flights flights, String filePath) throws JAXBException, IOException, Exception {
        this.flights = flights;
        this.filePath = filePath;
        
        JAXBContext jc = JAXBContext.newInstance(Flights.class);
        Marshaller m = jc.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        FileOutputStream fout = new FileOutputStream(filePath);
        m.marshal(flights, fout);
        m.marshal(flights, System.out);
        fout.close();
    }
    
    public void addSeat(int flightId) throws JAXBException, IOException, Exception
    {
        flights.addSeat(flightId);
    }
    
    public void removeSeat(int flightId) throws JAXBException, IOException, Exception
    {
        flights.removeSeat(flightId);
    }
    
    public ArrayList<Flight> getListbyCustomerID(int customerID)
    {
        return flights.getCustomerID(customerID);
    }
    
    public ArrayList<Flight> getListbyStatus(String status)
    {
        return flights.getStatus(status);
    }


    /**
     * @return the users
     */
    public Flights getFlights() {
        return flights;
    }

    /**
     * @param users the users to set
     */
    public void setFlights(Flights flights) {
        this.flights = flights;
    }
    
}
