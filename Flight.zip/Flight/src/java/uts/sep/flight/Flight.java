/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.flight;

import java.io.*;        
import java.util.ArrayList;
import javax.xml.bind.annotation.*;
/**
 *
 * @author 11661143
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Flight implements Serializable{
    
    @XmlElement(name = "flightID")    
    private int flightID;
    
    @XmlElement(name = "flightName")    
    private String flightName;
     
    @XmlElement(name = "origin")    
    private String origin;
    
    @XmlElement(name = "destination")
    private String destination;
    
    @XmlElement(name = "deDate")
    private String deDate;
    
    @XmlElement(name = "reDate")
    private String reDate;
    
    @XmlElement(name = "price")
    private double price;
    
    @XmlElement(name = "seats")
    private int seats;
    
    @XmlElement(name = "type")
    private String type;
    
    @XmlElement(name = "customerId")
    private int customerId;
    
    @XmlElement(name = "status")
    private String status;

    public Flight() {
    }
    
    // constructure for flight
    public Flight(int flightID, String flightName, String origin, String destination, String deDate, String reDate, double price, int seats, String type) {
        
        this.flightID = flightID;
        this.flightName = flightName;
        this.origin = origin;
        this.destination = destination;
        this.deDate = deDate;
        this.reDate = reDate;
        this.price = price;
        this.seats = seats;
        this.type = type;
    }
    
  // constructure for create a list of flight
    public Flight(int flightID, String flightName, String origin, String destination, String deDate, String reDate, double price, int seats, String type, int customerId, String status) {

        this.flightID = flightID;
        this.flightName = flightName;
        this.origin = origin;
        this.destination = destination;
        this.deDate = deDate;
        this.reDate = reDate;
        this.price = price;
        this.seats = seats;
        this.type = type;
        this.customerId = customerId;
        this.status = status;
    }
    
    public int getID() {
        return flightID;
    }

    public void setID(int flightID) {
        this.flightID = flightID;
    }
    
    
    public String getName() {
        return flightName;
    }

    public void setName(String flightName) {
        this.flightName = flightName;
    }
    
    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }    
    
    public String getDeDate() {
        return deDate;
    }

    public void setDeDate(String deDate) {
        this.deDate = deDate;
    }
    
    public String getReDate() {
        return reDate;
    }

    public void setReDate(String reDate) {
        this.reDate = reDate;
    }    
    
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }    
    
    public int getSeat() {
        return seats;
    }

    public void setSeat(int seats) {
        this.seats = seats;
    }    
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCustomerId()
    {
        return customerId;
    }
    
    public void setCustomerId(int customerId)
    {
        this.customerId = customerId;
    }
    
    public String getStatus()
    {
        return status;
    }
    
    public void setStatus(String status)
    {
        this.status = status;
    }   
}