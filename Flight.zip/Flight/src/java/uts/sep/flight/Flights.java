/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.flight;

import java.util.*;
import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD) 

@XmlRootElement(name = "flights")
public class Flights implements Serializable {
    
    @XmlElement(name = "flight")
    private ArrayList<Flight> flightList = new ArrayList<Flight>();
    
    private ArrayList<Flight> matchFlight = new ArrayList<Flight>();
 
    // return flight list
    public ArrayList<Flight> getList() {
        return flightList;
    }
    
    public ArrayList<Flight> getSearchList(){
        return matchFlight;
    }
     
    public void addFlight(Flight flight) {
        flightList.add(flight);
    }
    
    public void removeFlight(Flight flight) {
        flightList.remove(flight);
    }
    
    // return search list that matches parameters
    public void searchFlights(String origin, String destination){
            
        for(Flight flight : flightList)
        {
            if(flight.getOrigin().equals(origin) && flight.getDestination().equals(destination))
            {
                matchFlight.add(flight);
            }
        }
    }
    
     public void searchFlighs(String origin, String destination, String deDate, String reDate, String type){
            
        for(Flight flight : flightList)
        {
            if(reDate == null)
            {
                if(flight.getOrigin().equals(origin) && flight.getDestination().equals(destination) && flight.getDeDate().equals(deDate) && flight.getType().equals(type))
                {
                    matchFlight.add(flight);
                }
            }
            else
            {
                if(flight.getOrigin().equals(origin) && flight.getDestination().equals(destination) && flight.getDeDate().equals(deDate) && flight.getReDate().equals(reDate) && flight.getType().equals(type))
                {
                    matchFlight.add(flight);
                }
            }
        }
    }
    
    public Flight getFlight(int flightID){
        for(Flight flight : flightList)
        {
            if(flight.getID() == flightID)
            {
                return flight;
            }
        }
        
        return null;
    }
    
    public Flight getCustomer(int customerID){
        for(Flight flight : flightList)
        {
            if(flight.getCustomerId() == customerID)
            {
                return flight;
            }
        }
        
        return null;
    }
        
    public Flight getSeat(int flightID)
    {
        for(Flight flight : flightList)
        {
            if(flight.getID() == flightID)
            {
                return flight;
            }
        }
        
        return null;
    }
    
    public void addSeat(int flightId)
    {
        for(Flight flight : flightList)
        {
            if(flight.getID() == flightId)
            {
                int updateSeat = flight.getSeat()-1;
                flight.setSeat(updateSeat);
            }
        }
    }
    
    public void removeSeat(int flightId){
        for(Flight flight : flightList)
        {
            if(flight.getID() == flightId)
            {
                int updateSeat = flight.getSeat()+1;
                flight.setSeat(updateSeat);
            }
        }
    }
    
    public ArrayList<Flight> getStatus(String status)
    {
        ArrayList<Flight> list = new ArrayList<Flight>();
        
        for(Flight flight : flightList)
        {
            if(flight.getStatus().equals(status))
            {
                list.add(flight);
            }
        }
        return list;
    }
    
    public ArrayList<Flight> getCustomerID(int customerID)
    {
        ArrayList<Flight> list = new ArrayList<Flight>();
        
        for(Flight flight : flightList)
        {
            if(flight.getCustomerId() == customerID)
            {
                list.add(flight);
            }
        }
        return list;
    }

}