package uts.sep.flight;

import java.io.Serializable;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;



public class TestJAXB implements Serializable {
	public static void main(String[] args) throws Exception {
	
		Flights flights = new Flights();
                flights.addFlight(new Flight(1235, "heelo", "sydeny", "adelie", "2017-05-29", "2017-12-13", 90, 20, "Economy",123,"Available"));
		// Boilerplate code to convert objects to XML...
		JAXBContext jc = JAXBContext.newInstance(Flights.class);
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(flights, System.out);
	}
}
