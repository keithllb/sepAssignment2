/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.sep.user;

import java.util.*;
import java.io.Serializable;
import javax.xml.bind.annotation.*;
 
@XmlAccessorType(XmlAccessType.FIELD)

@XmlRootElement(name = "users")
public class Users implements Serializable {
    
    @XmlElement(name = "user")
    private ArrayList<User> userList = new ArrayList<User>();
 
    public ArrayList<User> getList() {
        return userList;
    }
    public void addUser(User user) {
        userList.add(user);
    }
    public void removeUser(User user) {
        userList.remove(user);
    }
    
    public ArrayList<User> getAllUsers()
    {
        ArrayList<User> list = new ArrayList();
        
        for(User user : userList)
        {
            list.add(user);
        }
        
        return list;
    }
    
    public User getEmail(String email){
         for (User user : userList) {
            if (user.getEmail().equals(email)) {
                return user;
            }
        }
         return null;
    }
    
    public boolean checkPassword(int userID, String password){
        for(User user: userList)
        {
            if(user.getID() == userID && user.getPassword().equals(password))
            {
                return true;
            }
        }
        return false;
    }
    
    public User getID(int ID) {
        for (User user : userList) {
            if (user.getID() == ID) {
                return user;
            }
        }
        return null;
    }
    
    public User login(String email, String password) {
        
        for (User user : userList) {
            if (user.getEmail().equals(email)&& user.getPassword().equals(password))
                return user; 
        }
        return null; 
    }
    

    public User logout(String email, String password) {
        
        for (User user : userList) {
            if (user.getEmail().equals(email)&& user.getPassword().equals(password))
                
            return user;
        }
        return null; 
    }

    
}