package uts.sep.rest;
 
import javax.servlet.ServletContext;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBException;
import java.io.*;
import java.util.ArrayList;
import uts.sep.flight.*;
 
@Path("/FlightList")
public class FlightList {
 @Context
 private ServletContext application;
 
 private FlightApplication getFlightApp() throws JAXBException, IOException, Exception {
  // The web server can handle requests from different clients in parallel.
  // These are called "threads".
  //
  // We do NOT want other threads to manipulate the application object at the same
  // time that we are manipulating it, otherwise bad things could happen.
  //
  // The "synchronized" keyword is used to lock the application object while
  // we're manpulating it.
  synchronized (application) {
   FlightApplication flightApp = (FlightApplication)application.getAttribute("diaryApp");
   if (flightApp == null) {
    flightApp = new FlightApplication();
    flightApp.setFilePath(application.getRealPath("WEB-INF/listFlight.xml"));
    application.setAttribute("flightApp", flightApp);
   }
   return flightApp;
  }
 }
 
 @Path("flight")
 @GET
 @Produces(MediaType.APPLICATION_XML)
 public Flights getLists() throws IOException, Exception
 {
     return getFlightApp().getFlights();
 }

    
    @Path("flight/{customerID}")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public ArrayList<Flight> getListByID(@PathParam("customerID") int customerID) throws IOException, Exception {
        return getFlightApp().getListbyCustomerID(customerID);
    }
    
    @Path("flight/{customerID}/{status}")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public ArrayList<Flight> getListByStatus(@PathParam("status") String status) throws IOException, Exception {
        return getFlightApp().getListbyStatus(status);
    }
    
    @Path("flight//{status}")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public ArrayList<Flight> getListByStatuss(@PathParam("status") String status) throws IOException, Exception {
        return getFlightApp().getListbyStatus(status);
    }
    
}